﻿
public interface IMyList:IAddRemoveCollection
{
    int Used { get; set; }
    
}
