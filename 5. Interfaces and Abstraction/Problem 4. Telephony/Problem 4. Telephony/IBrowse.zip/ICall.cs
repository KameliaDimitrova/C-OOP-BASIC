﻿
public interface ICall
{
    string GetCalling();
}
