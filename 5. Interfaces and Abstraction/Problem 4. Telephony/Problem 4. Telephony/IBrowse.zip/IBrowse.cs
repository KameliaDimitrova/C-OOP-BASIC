﻿public interface IBrowse
{
    string Browsing();
}
