﻿
public interface IEnter
{
    string Id { get; set; }
}
