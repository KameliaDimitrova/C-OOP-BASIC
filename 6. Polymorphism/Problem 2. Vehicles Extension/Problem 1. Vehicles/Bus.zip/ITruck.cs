﻿
public interface ITruck
{
    string Drive(double kmToDrive, string vehil, double increaseConsumation);
    void Refuel(double fuel);
}

