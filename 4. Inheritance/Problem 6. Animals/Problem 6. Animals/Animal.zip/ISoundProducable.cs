﻿
interface ISoundProducable
{
    string ProduceSound();
}
