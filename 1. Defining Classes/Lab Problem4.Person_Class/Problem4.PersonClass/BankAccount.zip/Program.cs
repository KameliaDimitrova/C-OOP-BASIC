﻿using System;

namespace Problem4.PersonClass
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
